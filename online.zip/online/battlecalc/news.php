<?php 

echo "Fixed some errors due to update from PHP 4.x to PHP 5.x, 7x";

?>

